# ============================================================================
# Agente de Impressão — Padrão HEMC
# ============================================================================
# O que isso faz:
#   Fica escutando em http://localhost:38900, esperando o navegador mandar o
#   conteúdo ZPL de uma etiqueta. Quando recebe, salva num arquivo temporário
#   e executa "copy /b arquivo.zpl LPT1" — exatamente o mesmo comando que a
#   TI já roda manualmente em outros setores.
#
# Pré-requisito:
#   A porta da impressora já precisa estar mapeada como LPT1 nesta máquina
#   (o "net use lpt1 \\SERVIDOR\COMPARTILHAMENTO /persistent:yes" que vocês
#   já rodaram). Este agente NÃO faz esse mapeamento — só usa o que já
#   existe.
#
# Por que roda por PowerShell e não precisa instalar nada:
#   PowerShell já vem no Windows. Não precisa instalar Node.js, Python, nem
#   nenhum programa de terceiro — só este script.
#
# IMPORTANTE — precisa rodar no mesmo usuário que fez o "net use":
#   O mapeamento de LPT1 é por usuário/sessão do Windows, não é global da
#   máquina. Por isso este script deve iniciar no LOGON do usuário (pasta
#   Inicializar), nunca como Serviço do Windows rodando em outra conta —
#   um Serviço não enxergaria o LPT1 mapeado pelo usuário.
# ============================================================================

$porta = 38900
$portaImpressora = "LPT1"

$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://localhost:$porta/")

try {
    $listener.Start()
} catch {
    Write-Host "ERRO: não foi possível iniciar na porta $porta. Já tem outro agente rodando?" -ForegroundColor Red
    exit 1
}

Write-Host "Agente de Impressão Padrao HEMC rodando em http://localhost:$porta" -ForegroundColor Green
Write-Host "Enviando etiquetas para a porta: $portaImpressora"
Write-Host "Pressione Ctrl+C para encerrar (ou feche esta janela)."

function Responder($response, [int]$statusCode, [string]$corpoJson) {
    $response.Headers.Add("Access-Control-Allow-Origin", "*")
    $response.Headers.Add("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
    $response.Headers.Add("Access-Control-Allow-Headers", "Content-Type")
    $response.ContentType = "application/json; charset=utf-8"
    $response.StatusCode = $statusCode
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($corpoJson)
    $response.OutputStream.Write($bytes, 0, $bytes.Length)
    $response.Close()
}

while ($listener.IsListening) {
    $context = $listener.GetContext()
    $request = $context.Request
    $response = $context.Response

    try {
        if ($request.HttpMethod -eq "OPTIONS") {
            Responder $response 204 "{}"
            continue
        }

        if ($request.Url.AbsolutePath -eq "/status" -and $request.HttpMethod -eq "GET") {
            Responder $response 200 ('{"status":"ok","porta":"' + $portaImpressora + '"}')
            continue
        }

        if ($request.Url.AbsolutePath -eq "/imprimir" -and $request.HttpMethod -eq "POST") {
            $reader = New-Object System.IO.StreamReader($request.InputStream, [System.Text.Encoding]::UTF8)
            $zpl = $reader.ReadToEnd()
            $reader.Close()

            if ([string]::IsNullOrWhiteSpace($zpl)) {
                Responder $response 400 '{"ok":false,"erro":"Conteudo ZPL vazio."}'
                continue
            }

            $arquivoTemp = Join-Path $env:TEMP ("etiqueta_" + (Get-Date -Format "yyyyMMddHHmmssfff") + ".zpl")
            try {
                [System.IO.File]::WriteAllText($arquivoTemp, $zpl, [System.Text.Encoding]::ASCII)

                $resultado = cmd /c "copy /b `"$arquivoTemp`" $portaImpressora" 2>&1
                $sucesso = $LASTEXITCODE -eq 0

                Remove-Item $arquivoTemp -ErrorAction SilentlyContinue

                if ($sucesso) {
                    Responder $response 200 '{"ok":true}'
                } else {
                    $erroTexto = (($resultado -join " ") -replace '"', "'") -replace "[\r\n]+", " "
                    Responder $response 500 ('{"ok":false,"erro":"' + $erroTexto + '"}')
                }
            } catch {
                Remove-Item $arquivoTemp -ErrorAction SilentlyContinue
                $erroTexto = ($_.Exception.Message -replace '"', "'") -replace "[\r\n]+", " "
                Responder $response 500 ('{"ok":false,"erro":"' + $erroTexto + '"}')
            }
            continue
        }

        Responder $response 404 '{"ok":false,"erro":"Rota nao encontrada."}'
    } catch {
        try { Responder $response 500 '{"ok":false,"erro":"Erro interno do agente."}' } catch {}
    }
}
