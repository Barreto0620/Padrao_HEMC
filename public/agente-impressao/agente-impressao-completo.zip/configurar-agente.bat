@echo off
REM ============================================================================
REM Configurar Agente de Impressao (execute uma vez) - Padrao HEMC
REM ============================================================================
REM Duplo clique aqui registra a Tarefa Agendada — depois disso o agente fica
REM permanente, invisivel, e reinicia sozinho se cair. Só precisa rodar de
REM novo se reinstalar o Windows ou trocar de usuário.
REM
REM Pede elevação de administrador automaticamente (aparece o aviso do
REM Windows/UAC) — algumas máquinas com política de segurança mais travada
REM exigem isso pra criar Tarefa Agendada. Use a MESMA conta que efetivamente
REM vai usar a impressora no dia a dia, não a conta de outra pessoa — o
REM script confirma no final pra qual usuário a tarefa ficou registrada.
REM ============================================================================

net session >nul 2>&1
if %errorLevel% == 0 goto :executar

echo Pedindo permissao de administrador ao Windows...
powershell -Command "Start-Process '%~f0' -Verb RunAs"
exit /b

:executar
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0registrar-agente.ps1"
echo.
pause
