' ============================================================================
' Lançador oculto do Agente de Impressão — Padrão HEMC
' ============================================================================
' Diferente de só usar "-WindowStyle Hidden" no PowerShell (que é instável —
' em alguns Windows/antivírus a janela aparece minimizada mesmo assim, foi
' o que causou o problema original), este VBS garante janela ZERO. É o
' truque clássico usado por administradores de sistema há anos: o VBS chama
' o PowerShell através do WScript.Shell com o parâmetro de estilo de janela
' 0 (oculta de verdade) e "False" pra não travar esperando o processo.
'
' Não precisa clicar neste arquivo manualmente no dia a dia — quem chama ele
' é a Tarefa Agendada (ver registrar-agente.ps1). Só use direto se quiser
' testar que sobe mesmo sem aparecer nada na tela.
' ============================================================================

Dim objShell, objFSO, pastaScript, caminhoPs1

Set objShell = CreateObject("WScript.Shell")
Set objFSO = CreateObject("Scripting.FileSystemObject")

pastaScript = objFSO.GetParentFolderName(WScript.ScriptFullName)
caminhoPs1 = pastaScript & "\hemc-print-agent.ps1"

objShell.Run "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & caminhoPs1 & """", 0, False
