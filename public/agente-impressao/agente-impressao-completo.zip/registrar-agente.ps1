﻿# ============================================================================
# Registrar Agente de Impressão como Tarefa Agendada - Padrão HEMC
# ============================================================================
# Roda UMA VEZ por computador (não precisa admin - cria a tarefa só pro
# usuário atual, sem privilégio elevado). Depois disso, o agente:
#   - Inicia sozinho sempre que ESTE usuário fizer login no Windows
#   - Fica completamente invisível (via iniciar-agente-oculto.vbs)
#   - Reinicia sozinho automaticamente se cair por algum motivo
#   - Não aparece no Alt+Tab nem na barra de tarefas - nada pra fechar
#     sem querer
#
# IMPORTANTE: rode este script logado com o MESMO usuário do Windows que vai
# imprimir no dia a dia - é a sessão dele que precisa ter o LPT1 mapeado
# (o "net use lpt1 \\SERVIDOR\COMPARTILHAMENTO /persistent:yes").
# ============================================================================

$nomeTarefa = "HEMC - Agente de Impressao"
$vbsPath = Join-Path $PSScriptRoot "iniciar-agente-oculto.vbs"

if (-not (Test-Path $vbsPath)) {
    Write-Host "ERRO: iniciar-agente-oculto.vbs não encontrado na mesma pasta deste script." -ForegroundColor Red
    Write-Host "Baixe todos os arquivos do Agente de Impressão para a mesma pasta." -ForegroundColor Red
    exit 1
}

$acao = New-ScheduledTaskAction -Execute "wscript.exe" -Argument "`"$vbsPath`""
$gatilho = New-ScheduledTaskTrigger -AtLogOn

$config = New-ScheduledTaskSettingsSet `
    -RestartCount 999 `
    -RestartInterval (New-TimeSpan -Minutes 1) `
    -ExecutionTimeLimit (New-TimeSpan -Days 0) `
    -AllowStartIfOnBatteries `
    -DontStopIfGoingOnBatteries `
    -StartWhenAvailable

$principal = New-ScheduledTaskPrincipal `
    -UserId "$env:USERDOMAIN\$env:USERNAME" `
    -LogonType Interactive `
    -RunLevel Limited

$ehAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $ehAdmin) {
    Write-Host "AVISO: este PowerShell nao esta rodando como Administrador." -ForegroundColor Yellow
    Write-Host "Em computadores com politica de seguranca mais travada, isso pode causar" -ForegroundColor Yellow
    Write-Host "erro de 'Acesso negado' logo abaixo. Se der erro, feche esta janela e rode" -ForegroundColor Yellow
    Write-Host "'configurar-agente.bat' de novo (ele agora pede elevacao sozinho)." -ForegroundColor Yellow
    Write-Host ""
}

try {
    Register-ScheduledTask `
        -TaskName $nomeTarefa `
        -Action $acao `
        -Trigger $gatilho `
        -Settings $config `
        -Principal $principal `
        -Force `
        -ErrorAction Stop `
        -Description "Agente de impressao local do Padrao HEMC - encaminha etiquetas ZPL para a porta da impressora (LPT1). Sem interface, sem janela." `
        | Out-Null

    Write-Host ""
    Write-Host "Tarefa '$nomeTarefa' criada com sucesso." -ForegroundColor Green
    Write-Host "Registrada para o usuario: $env:USERDOMAIN\$env:USERNAME" -ForegroundColor Green
    Write-Host "(confira se e o MESMO usuario que vai usar a impressora no dia a dia -" -ForegroundColor Green
    Write-Host " se a elevacao de administrador pediu outra conta, rode este script de" -ForegroundColor Green
    Write-Host " novo ja logado com o usuario certo)" -ForegroundColor Green
    Write-Host "O agente vai iniciar sozinho, invisivel, no proximo login deste usuario." -ForegroundColor Green
    Write-Host ""
    Write-Host "Quer testar agora sem precisar deslogar? Rode:" -ForegroundColor Cyan
    Write-Host "  Start-ScheduledTask -TaskName `"$nomeTarefa`"" -ForegroundColor Cyan
    Write-Host ""
} catch {
    Write-Host ""
    Write-Host "ERRO: nao foi possivel criar a tarefa agendada." -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host ""
    if ($_.Exception.Message -match "Acesso negado|Access is denied|0x80070005") {
        Write-Host "Isso e erro de PERMISSAO. Tente nesta ordem:" -ForegroundColor Yellow
        Write-Host "1. Feche esta janela e rode 'configurar-agente.bat' de novo (ele ja pede" -ForegroundColor Yellow
        Write-Host "   elevacao de administrador sozinho agora)." -ForegroundColor Yellow
        Write-Host "2. Se AINDA der o mesmo erro mesmo como administrador, a politica de grupo" -ForegroundColor Yellow
        Write-Host "   (GPO) deste computador esta bloqueando criacao de tarefa agendada de" -ForegroundColor Yellow
        Write-Host "   proposito. Nesse caso, fale com quem administra o Active Directory/GPO" -ForegroundColor Yellow
        Write-Host "   da rede para liberar essa permissao para este usuario ou computador." -ForegroundColor Yellow
    }
    Write-Host ""
    exit 1
}
